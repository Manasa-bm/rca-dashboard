package com.example.rca_dashboard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RcaDashboardApplication {

	public static void main(String[] args) {
		SpringApplication.run(RcaDashboardApplication.class, args);
	}

}
